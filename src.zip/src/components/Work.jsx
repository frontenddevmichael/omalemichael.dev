import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import SpecSection from './SpecSection';
import ContributionGraph from './ContributionGraph';
import { fetchRepos, fetchCommit } from '../utils/github';
import ProjectDetail from './ProjectDetail';

// GitHub language colors — a minimal set for the languages in this repo list
const LANG_COLORS = {
  TypeScript: '#3178c6',
  JavaScript: '#f1e05a',
  CSS: '#563d7c',
  HTML: '#e34c26',
  Python: '#3572a5',
  React: '#61dafb',
};

function langColor(lang) {
  return LANG_COLORS[lang] || '#666';
}

const FEATURED_PROJECT = {
  name: 'Synapse',
  tagline: 'Collaborative learning platform with AI-powered quizzes',
  problem:
    'Students and teams studying together need a way to turn study materials into active recall practice. Existing flashcard apps are static \u2014 they don\u2019t generate questions from your notes or adapt to what you\u2019re getting wrong.',
  decisions: [
    'Authentication + room system via Supabase so each study group gets a private space with owner and admin roles.',
    'Upload any document (PDF, DOCX, pasted text) and run it through OpenAI to generate multiple-choice and true/false questions at configurable difficulty.',
    'Built-in SM-2 spaced repetition algorithm that automatically identifies weak questions and schedules reviews \u2014 no manual curation needed.',
  ],
  result:
    'A live learning platform where users upload materials, get AI-generated quizzes, compete on leaderboards, and reinforce weak areas through spaced repetition. Deployed with offline support, push notifications, and full authentication.',
  tech: ['TypeScript', 'React', 'Supabase', 'OpenAI', 'Vite'],
  live: 'https://synapse-khaki.vercel.app',
  repo: 'https://github.com/frontenddevmichael/synapse',
};

const STATIC_PROJECTS = [
  {
    name: 'Pig Game',
    desc: 'Two-player dice game with React state management. Real-time score tracking with smooth CSS transitions and animations.',
    lang: 'React',
    topics: ['React', 'State', 'Animation'],
    meta: { l: 'Type', v: 'Game' },
  },
  {
    name: 'Portfolio v2',
    desc: 'This site — command palette, parallax effects, sticky cards, and a fully responsive layout system with 6 breakpoints.',
    lang: 'React',
    topics: ['React', 'CSS Grid', 'Responsive'],
    meta: { l: 'Design', v: 'Custom' },
  },
];

function safeHostname(url) {
  try {
    const u = url.startsWith('http') ? new URL(url) : new URL('https://' + url);
    return u.hostname.replace('www.', '');
  } catch { return null; }
}

const repoIcon = (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 00-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0020 4.77 5.07 5.07 0 0019.91 1S18.73.65 16 2.48a13.38 13.38 0 00-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 005 4.77a5.44 5.44 0 00-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 009 18.13V22"/></svg>
);

export default function Work() {
  const [repos, setRepos] = useState(null);
  const [activeTag, setActiveTag] = useState('All');
  const [selectedProject, setSelectedProject] = useState(null);
  const [commits, setCommits] = useState({});
  const gridRef = useRef(null);

  useEffect(() => {
    fetchRepos()
      .then(data => setRepos(data))
      .catch(() => setRepos([]));
  }, []);

  // Fetch latest commit for each repo on load (parallel)
  useEffect(() => {
    if (!repos || repos.length === 0) return;
    let cancelled = false;
    const batch = repos.slice(0, 12);
    Promise.all(
      batch.map(async (r) => {
        const c = await fetchCommit(r.name);
        return { name: r.name, commit: c };
      })
    ).then((results) => {
      if (cancelled) return;
      const map = {};
      results.forEach(({ name, commit }) => {
        if (commit) map[name] = commit;
      });
      setCommits(map);
    });
    return () => { cancelled = true; };
  }, [repos]);

  const featured = useMemo(() => {
    if (!repos || repos.length === 0) return FEATURED_PROJECT;
    const synapse = repos.find(r => r.name.toLowerCase() === 'synapse');
    if (!synapse) return FEATURED_PROJECT;

    const tech = synapse.topics && synapse.topics.length >= 3
      ? synapse.topics.slice(0, 5)
      : synapse.lang
        ? [synapse.lang, ...(synapse.topics || [])].slice(0, 5)
        : FEATURED_PROJECT.tech;

    return {
      ...FEATURED_PROJECT,
      tagline: synapse.desc || FEATURED_PROJECT.tagline,
      tech,
      live: synapse.live || FEATURED_PROJECT.live,
      repo: synapse.url || FEATURED_PROJECT.repo,
    };
  }, [repos]);

  const hasRepos = repos !== null;
  const gridItems = useMemo(() => {
    if (hasRepos && repos.length > 0) {
      return repos.slice(0, 12).map(r => ({
        key: r.name,
        name: r.name,
        title: r.name.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
        desc: r.desc || '',
        tags: r.topics && r.topics.length ? r.topics.slice(0, 4) : (r.lang ? [r.lang] : []),
        meta: r.stars != null ? { l: 'Stars', v: r.stars } : null,
        live: r.live,
        href: r.live || r.url,
        lang: r.lang,
        stars: r.stars,
      }));
    }
    return STATIC_PROJECTS.map(p => ({
      key: p.name,
      name: p.name,
      title: p.name,
      desc: p.desc,
      tags: p.topics,
      meta: p.meta,
      live: null,
      href: null,
      lang: p.lang,
      stars: null,
    }));
  }, [hasRepos, repos]);

  // Scroll-triggered IntersectionObserver for card entrance animations
  // Must be placed AFTER gridItems declaration to avoid TDZ error
  useEffect(() => {
    const grid = gridRef.current;
    if (!grid) return;
    const cards = grid.querySelectorAll('.proj-card:not(.in-view)');
    if (!cards.length) return;
    const obs = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add('in-view');
        obs.unobserve(entry.target);
      });
    }, { threshold: 0.05, rootMargin: '0px 0px -40px 0px' });
    cards.forEach(el => obs.observe(el));
    return () => obs.disconnect();
  }, [gridItems.length]);

  // Mouse tracking glow on grid
  const handleGridMouse = useCallback((e) => {
    const grid = gridRef.current;
    if (!grid) return;
    const rect = grid.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    grid.style.setProperty('--mmx', x);
    grid.style.setProperty('--mmy', y);
  }, []);

  const tags = useMemo(() => {
    const set = new Set();
    gridItems.forEach(it => it.tags.forEach(t => set.add(t)));
    return ['All', ...Array.from(set).sort()];
  }, [gridItems]);

  const filtered = activeTag === 'All'
    ? gridItems
    : gridItems.filter(it => it.tags.includes(activeTag));

  const openDetail = useCallback((item) => {
    setSelectedProject(item);
  }, []);

  const closeDetail = useCallback(() => {
    setSelectedProject(null);
  }, []);

  return (
    <SpecSection id="work" num="02" title="Work">
      <ContributionGraph />

      {/* Featured Project */}
      <div className="featured-proj stagger-up" style={{ marginTop: 'var(--space-2xl)', '--lang-color': '#61dafb' }}>
        <div className="featured-proj-head">
          <span className="tag tag--featured">
            <span className="tag-dot"></span>
            Featured
          </span>
          <h3>{featured.name}</h3>
          <p className="featured-tagline">{featured.tagline}</p>
        </div>
        <div className="featured-proj-body">
          <div className="fp-block">
            <span className="fp-label">Problem</span>
            <p>{featured.problem}</p>
          </div>
          <div className="fp-block">
            <span className="fp-label">Decisions</span>
            <ul>
              {featured.decisions.map((d, i) => <li key={i}>{d}</li>)}
            </ul>
          </div>
          <div className="fp-block">
            <span className="fp-label">Result</span>
            <p>{featured.result}</p>
          </div>
        </div>
        <div className="featured-proj-foot">
          <div className="proj-specs">
            {featured.tech.map(t => <span key={t} className="s">{t}</span>)}
          </div>
          <div className="fp-links">
            {featured.live && (
              <a href={featured.live} target="_blank" rel="noopener noreferrer" className="btn btn--ghost">Live site</a>
            )}
            {featured.repo && (
              <a href={featured.repo} target="_blank" rel="noopener noreferrer" className="btn btn--ghost">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" style={{width:14,height:14}}><path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 00-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0020 4.77 5.07 5.07 0 0019.91 1S18.73.65 16 2.48a13.38 13.38 0 00-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 005 4.77a5.44 5.44 0 00-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 009 18.13V22"/></svg>
                Code
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Tag filters */}
      {tags.length > 2 && (
        <div className="proj-filters" role="tablist" aria-label="Filter projects by tag">
          {tags.map(t => (
            <button
              key={t}
              role="tab"
              aria-selected={activeTag === t}
              className={`proj-filter${activeTag === t ? ' active' : ''}`}
              onClick={() => setActiveTag(t)}
            >
              {t}
            </button>
          ))}
        </div>
      )}

      {/* Bento grid with mouse tracking glow */}
      <div
        className="proj-grid proj-grid--bento proj-grid--track"
        style={{ marginTop: 'var(--space-xl)' }}
        ref={gridRef}
        onMouseMove={handleGridMouse}
      >
        {filtered.length === 0 ? (
          <div className="proj proj-card">
            <div className="head"><span className="tag">note</span></div>
            <h3>No projects match this filter</h3>
            <p>Try a different tag.</p>
          </div>
        ) : (
          filtered.map((it, i) => {
            const hostname = it.live ? safeHostname(it.live) : null;
            const langColorVal = langColor(it.lang);
            const c = commits[it.name];

            const body = (
              <>
                <div className="head">
                  <span className="head-icon-wrap">{repoIcon}</span>
                  <span className="tag">{it.tags[0] || 'project'}</span>
                </div>
                <h3>{it.title}</h3>
                <p>{it.desc}</p>
                <div className="proj-meta">
                  {it.lang && (
                    <span className="proj-lang">
                      <span className="proj-lang-dot" style={{ background: langColorVal }} />
                      {it.lang}
                    </span>
                  )}
                  {hostname && (
                    <span className="proj-hostname">{hostname}</span>
                  )}
                  {it.stars != null && (
                    <span className="proj-stars">
                      <svg className="star-icon" viewBox="0 0 16 16" fill="currentColor" width="12" height="12"><path d="M8 .25a.75.75 0 01.673.418l1.882 3.815 4.21.612a.75.75 0 01.416 1.279l-3.046 2.97.719 4.192a.75.75 0 01-1.088.791L8 12.347l-3.766 1.98a.75.75 0 01-1.088-.79l.72-4.192L.818 6.374a.75.75 0 01.416-1.28l4.21-.611L7.327.668A.75.75 0 018 .25z"/></svg>
                      <span className="star-count">{it.stars}</span>
                    </span>
                  )}
                </div>
                <div className="proj-foot">
                  {it.live && (
                    <span className="proj-live-badge">
                      <span className="live-dot"></span>
                      Live
                    </span>
                  )}
                  {c?.date && (
                    <span className="proj-commit-info">
                      <svg viewBox="0 0 16 16" fill="currentColor" width="10" height="10">
                        <path d="M8 0a8 8 0 100 16A8 8 0 008 0zm0 14.5a6.5 6.5 0 110-13 6.5 6.5 0 010 13zM7.5 4a.5.5 0 01.5.5V8l3 1.5a.5.5 0 01-.5.866l-3.5-1.75A.5.5 0 017 8V4.5a.5.5 0 01.5-.5z"/>
                      </svg>
                      {((Date.now() - new Date(c.date).getTime()) / 86400000).toFixed(0)}d ago
                    </span>
                  )}
                  {it.tags.length > 0 && (
                    <div className="proj-specs">
                      {it.tags.slice(0, 4).map(t => <span key={t} className="s">{t}</span>)}
                    </div>
                  )}
                </div>
              </>
            );

            const style = {
              '--card-index': i,
              '--lang-color': langColorVal,
              transitionDelay: `${i * 60}ms`,
            };
            return (
              <div
                key={it.key}
                className="proj proj-card"
                style={style}
                data-card-index={i}
                onClick={() => openDetail({ ...it, hostname })}
                onMouseMove={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const x = ((e.clientX - rect.left) / rect.width) * 100;
                  const y = ((e.clientY - rect.top) / rect.height) * 100;
                  e.currentTarget.style.setProperty('--mx', x);
                  e.currentTarget.style.setProperty('--my', y);
                }}
              >
                {body}
              </div>
            );
          })
        )}
      </div>

      {/* Project Detail Modal */}
      {selectedProject && (
        <ProjectDetail
          project={selectedProject}
          commit={commits[selectedProject.name] || null}
          onClose={closeDetail}
        />
      )}
    </SpecSection>
  );
}
