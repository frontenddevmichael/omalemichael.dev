import { useEffect, useRef, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { timeAgo } from '../utils/github';
import { addScrollLock, removeScrollLock } from '../utils/scrollLock';

const LANG_COLORS = {
  TypeScript: '#3178c6',
  JavaScript: '#f1e05a',
  CSS: '#563d7c',
  HTML: '#e34c26',
  Python: '#3572a5',
  React: '#61dafb',
};

function langColor(lang) {
  return LANG_COLORS[lang] || '#666';
}

export default function ProjectDetail({ project, commit, onClose }) {
  const panelRef = useRef(null);
  const prevFocus = useRef(null);

  useEffect(() => {
    prevFocus.current = document.activeElement;
    panelRef.current?.focus();
    addScrollLock(); // shared module-level counter
    return () => {
      removeScrollLock(); // shared module-level counter
      prevFocus.current?.focus();
    };
  }, []);

  useEffect(() => {
    if (!onClose) return;
    const handler = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); onClose(); }
      if (e.key === 'Tab') {
        // Trap focus inside modal
        const focusable = panelRef.current?.querySelectorAll(
          'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        if (!focusable || focusable.length === 0) return;
        const first = focusable[0];
        const last = focusable[focusable.length - 1];
        if (e.shiftKey) {
          if (document.activeElement === first) { e.preventDefault(); last.focus(); }
        } else {
          if (document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  // Swipe-to-dismiss gesture state
  const touchStartY = useRef(null);

  const onTouchStart = useCallback((e) => {
    touchStartY.current = e.touches[0].clientY;
  }, []);

  const onTouchMove = useCallback((e) => {
    if (touchStartY.current === null) return;
    const panel = panelRef.current;
    if (!panel || panel.scrollTop > 0) return; // Only swipe when scrolled to top
    const delta = e.touches[0].clientY - touchStartY.current;
    if (delta < 0) return; // Only allow downward swipe
    const translate = Math.min(delta, 200);
    const opacity = Math.max(0, 1 - delta / 300);
    panel.style.transform = `translateY(${translate}px)`;
    panel.style.opacity = opacity;
    panel.style.transition = 'none';
  }, []);

  const onTouchEnd = useCallback((e) => {
    if (touchStartY.current === null) return;
    const delta = e.changedTouches[0].clientY - touchStartY.current;
    const panel = panelRef.current;
    if (panel) {
      panel.style.transition = '';
      panel.style.transform = '';
      panel.style.opacity = '';
    }
    if (delta > 120 && panel?.scrollTop === 0) {
      onClose();
    }
    touchStartY.current = null;
  }, [onClose]);

  if (!project) return null;

  const {
    title, desc, lang, tags, stars, live, href, hostname, name
  } = project;
  const color = lang ? langColor(lang) : null;
  const commitDate = commit?.date ? timeAgo(commit.date) : null;

  const body = (
    <div className="modal-overlay" onClick={onClose}>
      <div
        className="modal-panel"
        ref={panelRef}
        tabIndex={-1}
        role="dialog"
        aria-modal="true"
        aria-label={title || 'Project details'}
        onClick={e => e.stopPropagation()}
        onTouchStart={onTouchStart}
        onTouchMove={onTouchMove}
        onTouchEnd={onTouchEnd}
        onMouseMove={e => {
          // Mouse tracking glow on the modal panel
          const rect = panelRef.current?.getBoundingClientRect();
          if (rect) {
            const x = ((e.clientX - rect.left) / rect.width) * 100;
            const y = ((e.clientY - rect.top) / rect.height) * 100;
            panelRef.current?.style.setProperty('--mx', x);
            panelRef.current?.style.setProperty('--my', y);
          }
        }}
        style={{ '--lang-color': color || '#666' }}
      >
        {/* Close button */}
        <button className="modal-close" onClick={onClose} aria-label="Close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>

        {/* Header */}
        <div className="modal-head">
          <span className="modal-live-indicator">
            <span className="live-dot"></span>
            {live ? 'Deployed' : 'Repository'}
          </span>
          <h2 className="modal-title">{title || name}</h2>
          {desc && <p className="modal-desc">{desc}</p>}
        </div>

        {/* Meta row */}
        <div className="modal-meta">
          {lang && (
            <span className="modal-meta-item">
              <span className="proj-lang-dot" style={{ background: color }} />
              {lang}
            </span>
          )}
          {hostname && <span className="modal-meta-item">{hostname}</span>}
          {stars != null && (
            <span className="modal-meta-item modal-stars">
              <svg viewBox="0 0 16 16" fill="currentColor" width="12" height="12">
                <path d="M8 .25a.75.75 0 01.673.418l1.882 3.815 4.21.612a.75.75 0 01.416 1.279l-3.046 2.97.719 4.192a.75.75 0 01-1.088.791L8 12.347l-3.766 1.98a.75.75 0 01-1.088-.79l.72-4.192L.818 6.374a.75.75 0 01.416-1.28l4.21-.611L7.327.668A.75.75 0 018 .25z"/>
              </svg>
              {stars}
            </span>
          )}
          {commitDate && (
            <span className="modal-meta-item modal-commit-date">
              <svg viewBox="0 0 16 16" fill="currentColor" width="12" height="12">
                <path d="M8 0a8 8 0 100 16A8 8 0 008 0zm0 14.5a6.5 6.5 0 110-13 6.5 6.5 0 010 13zM7.5 4a.5.5 0 01.5.5V8l3 1.5a.5.5 0 01-.5.866l-3.5-1.75A.5.5 0 017 8V4.5a.5.5 0 01.5-.5z"/>
              </svg>
              Updated {commitDate}
            </span>
          )}
        </div>

        {/* Tags */}
        {tags && tags.length > 0 && (
          <div className="modal-tags">
            {tags.map(t => <span key={t} className="s">{t}</span>)}
          </div>
        )}

        {/* Commit detail */}
        {commit?.message && commit?.sha && (
          <div className="modal-commit">
            <svg viewBox="0 0 16 16" fill="currentColor" width="14" height="14">
              <path fillRule="evenodd" d="M10.5 7.75a2.5 2.5 0 11-5 0 2.5 2.5 0 015 0zm1.43.75a4.002 4.002 0 01-7.86 0H.75a.75.75 0 110-1.5h3.32a4.001 4.001 0 017.86 0h3.32a.75.75 0 110 1.5h-3.32z"/>
            </svg>
            <span className="modal-commit-sha">{commit.sha}</span>
            <span className="modal-commit-msg">{commit.message}</span>
          </div>
        )}

        {/* Actions */}
        <div className="modal-actions">
          {live && (
            <a href={live} target="_blank" rel="noopener noreferrer" className="btn btn--ghost btn--live">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
                <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>
              </svg>
              Live site
            </a>
          )}
          {href && (
            <a href={href} target="_blank" rel="noopener noreferrer" className="btn btn--ghost">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round">
                <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 00-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0020 4.77 5.07 5.07 0 0019.91 1S18.73.65 16 2.48a13.38 13.38 0 00-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 005 4.77a5.44 5.44 0 00-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 009 18.13V22"/>
              </svg>
              View code
            </a>
          )}
        </div>
      </div>
    </div>
  );

  return createPortal(body, document.body);
}
